enum AvailableStatus {
  available,
  unavailable,
  unknown,
}
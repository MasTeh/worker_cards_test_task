abstract class Avatar {  
  final String imageUrl;

  const Avatar({    
    required this.imageUrl,
  });
}
import 'package:worker_card/module/workers/domain/entity/skill.dart';

class WorkerSkill extends Skill {
  WorkerSkill({
    required super.name,
    required super.description,
    required super.level,
  });
}

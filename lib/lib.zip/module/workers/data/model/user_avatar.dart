import 'package:worker_card/module/workers/domain/entity/avatar.dart';

class UserAvatar extends Avatar {
  UserAvatar({required super.imageUrl});
}